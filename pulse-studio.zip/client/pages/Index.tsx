export default function Index() {
  return (
    <div className="min-h-screen w-full flex items-center justify-center px-4 py-6 sm:px-5 md:px-6 lg:px-8 relative overflow-hidden">
      {/* Background with gradient and pattern */}
      <div
        className="absolute inset-0 z-0"
        style={{
          background: `url('https://api.builder.io/api/v1/image/assets/TEMP/82b87801687dd5f8bb5a97c3a0a2b1d2d4a73f3c?width=880') lightgray 50% / cover no-repeat, linear-gradient(180deg, #FFF 0%, #D6AF9B 100%)`
        }}
      />

      {/* Main content container */}
      <div className="relative z-10 w-full max-w-xs sm:max-w-sm md:max-w-md mx-auto">
        <div className="flex flex-col items-center gap-8 sm:gap-10 md:gap-12">
          {/* Header section with logo and titles */}
          <div className="flex flex-col items-center gap-6 sm:gap-7 md:gap-8 w-full">
            {/* Logo */}
            <div className="w-24 h-24 sm:w-28 sm:h-28 md:w-[138px] md:h-[138px] flex-shrink-0">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/55dd6082e4beab7a6408f138a56c9c1eeeb18225?width=276"
                alt="Psychological Services Logo"
                className="w-full h-full object-contain"
                style={{ filter: 'drop-shadow(0 4px 4px rgba(174, 138, 59, 0.5))' }}
              />
            </div>

            {/* Name and subtitle */}
            <div className="flex flex-col items-center gap-3 sm:gap-4 md:gap-5 w-full">
              {/* Name with gradient */}
              <h1
                className="text-xl sm:text-2xl md:text-[32px] leading-none font-normal font-kugile text-center w-full sm:tracking-[0.8px] md:tracking-[1.6px] capitalize"
                style={{
                  background: 'linear-gradient(180deg, #EFAB19 0%, #625F5E 100%)',
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent',
                  backgroundClip: 'text'
                }}
              >
                Rodgoon Darvishi
              </h1>

              {/* Subtitle with multi-gradient */}
              <p
                className="text-lg sm:text-xl md:text-2xl leading-none font-medium font-garamond text-center w-full sm:tracking-[0.6px] md:tracking-[1.2px] capitalize"
                style={{
                  background: `
                    linear-gradient(to bottom right, #F4BF75 0%, #564325 50%) bottom right / 50% 50% no-repeat,
                    linear-gradient(to bottom left, #F4BF75 0%, #564325 50%) bottom left / 50% 50% no-repeat,
                    linear-gradient(to top left, #F4BF75 0%, #564325 50%) top left / 50% 50% no-repeat,
                    linear-gradient(to top right, #F4BF75 0%, #564325 50%) top right / 50% 50% no-repeat
                  `,
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent',
                  backgroundClip: 'text'
                }}
              >
                Psychological Services
              </p>
            </div>
          </div>

          {/* Contact buttons section */}
          <div
            className="w-full rounded-2xl sm:rounded-[20px] px-4 py-8 sm:px-5 sm:py-9 md:px-5 md:py-11"
            style={{
              background: 'rgba(196, 147, 122, 0.95)'
            }}
          >
            <div className="flex flex-col gap-4 sm:gap-5 md:gap-6 w-full">
              <ContactButton label="WhatsApp" href="https://wa.me/989392323606" />
              <ContactButton label="Telegram" href="https://t.me/Clinic_Darvishi" />
              <ContactButton label="Location" href="https://www.google.com/maps/place/35%C2%B045'44.8%22N+51%C2%B026'35.0%22E/@35.7625614,51.4430303,19z/data=!4m4!3m3!8m2!3d35.7624444!4d51.4430556?g_ep=Eg1tbF8yMDI1MTExMF8wIOC7DCoASAJQAg%3D%3D" />
              <ContactButton label="Email" href="mailto:Rodgoon.darvishi@gmail.com" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function ContactButton({ label, href }: { label: string; href: string }) {
  return (
    <a
      href={href}
      target={href.startsWith('http') ? '_blank' : undefined}
      rel={href.startsWith('http') ? 'noopener noreferrer' : undefined}
      className="flex items-center justify-center py-2 sm:py-2.5 md:py-2.5 px-3 sm:px-4 md:px-4 rounded-lg sm:rounded-xl border-2 sm:border-[3px] border-white transition-all hover:bg-white/10 active:scale-95"
    >
      <span
        className="text-lg sm:text-xl md:text-2xl font-bold font-garamond text-center sm:tracking-[0.6px] md:tracking-[1.2px] capitalize"
        style={{
          color: 'rgba(255, 255, 255, 0.77)'
        }}
      >
        {label}
      </span>
    </a>
  );
}
